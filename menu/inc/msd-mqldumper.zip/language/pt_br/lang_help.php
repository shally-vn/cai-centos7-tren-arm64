<?php
$lang['L_HELP_DB']="Esta é a lista de todos os bancos de dados";
$lang['L_HELP_PRAEFIX']="o prefixo é uma string no começo do nome da tabela, que funciona como um filtro.";
$lang['L_HELP_ZIP']="Compressão com GZip - estado recomendado é 'ativado'";
$lang['L_HELP_MEMORYLIMIT']="Quantidade máxima de memória em bytes para o script
0 = desativado";
$lang['L_MEMORY_LIMIT']="Limite de memória";
$lang['L_HELP_AD1']="Se ativado os arquivos de backup serão excluidos automaticamente.";
$lang['L_HELP_AD3']="número máximo de arquivos de backup (para autoexclusão)
0 = desativado";
$lang['L_HELP_LANG']="selecione seu idioma";
$lang['L_HELP_EMPTY_DB_BEFORE_RESTORE']="Para eliminar dados sem valor você pode configurar para limpar seu banco de dados antes de restaurar";
$lang['L_HELP_CRONEXTENDER']="Extensão dos scripts Perl, o padrão é '.pl'";
$lang['L_HELP_CRONSAVEPATH']="Nome do arquivo de configuração para o script Perl";
$lang['L_HELP_CRONPRINTOUT']="Se a saída estiver desativada ela não irá aparecer na tela.
Isto é independente de fazer impressão a partir do arquivo de log.";
$lang['L_HELP_CRONSAMEDB']="Usar o mesmo bd no trabalho Cron como está configurado o banco de dados?";
$lang['L_HELP_CRONDBINDEX']="escolha o banco de dados para o Cron";
$lang['L_HELP_FTPTRANSFER']="se ativado o arquivo será encaminhado via FTP.";
$lang['L_HELP_FTPSERVER']="Endereço do servidor de FTP";
$lang['L_HELP_FTPPORT']="Porta do servidor de FTP, padrão: 21";
$lang['L_HELP_FTPUSER']="digite o nome do usuário para o FTP";
$lang['L_HELP_FTPPASS']="digite a senha para o FTP";
$lang['L_HELP_FTPDIR']="onde está o diretório para upload? Digite o caminho!";
$lang['L_HELP_SPEED']="Velocidade mínima e máxima. O padrão é: 50 à 5000";
$lang['L_SPEED']="Controle de velocidade";
$lang['L_HELP_CRONEXECPATH']="Lugar dos scripts Perl.
O ponto de partida é o endereço HTTP (como um endereço no navegador)
Permitidas entradas absolutas ou relativas.";
$lang['L_CRON_EXECPATH']="Caminho dos scripts Perl";
$lang['L_HELP_CRONCOMPLETELOG']="Quando ativo o resultado completo será escrito em um arquivo_logcompleto.
Isto é independente de imprimir o texto";
$lang['L_HELP_FTP_MODE']="Quando você observar problemas usando a tranferência em FTP, ative o modo passivo.";


?>