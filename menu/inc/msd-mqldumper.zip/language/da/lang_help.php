<?php
$lang['L_HELP_DB']="Dette er listen over alle Databaser";
$lang['L_HELP_PRAEFIX']="præfikset er en streng i begyndelsen af et tabelnavn, hvilket kan bruges som et filter.";
$lang['L_HELP_ZIP']="Komprimering med GZip - anbefalet tilstand er 'aktiveret'";
$lang['L_HELP_MEMORYLIMIT']="Maksimal mængde hukommelse i Bytes for scriptet
0 = deaktiveret";
$lang['L_MEMORY_LIMIT']="Hukommelsesgrænse";
$lang['L_HELP_AD1']="Hvis aktiveret slettes backupfiler automatisk.";
$lang['L_HELP_AD3']="maksimum antal backupfilet (for autoslet)
0 = deaktiveret";
$lang['L_HELP_LANG']="vælg dit sprog";
$lang['L_HELP_EMPTY_DB_BEFORE_RESTORE']="For at eliminere nytteløse eller fejlagtige data kan du tømme databasen før genetablering";
$lang['L_HELP_CRONEXTENDER']="Filtype for Perl scripts, standard er '.pl'";
$lang['L_HELP_CRONSAVEPATH']="Navn på konfigurationsfilen for Perl scriptet";
$lang['L_HELP_CRONPRINTOUT']="Hvis deaktiveret skrives output ikke på skærmen.
Dette er uafhængigt af skrivningen til logfilen.";
$lang['L_HELP_CRONSAMEDB']="Brug samme database i Cron job som konfigureret under Database?";
$lang['L_HELP_CRONDBINDEX']="vælg databasen for Cron job";
$lang['L_HELP_FTPTRANSFER']="hvis aktiveret sendes filen via FTP.";
$lang['L_HELP_FTPSERVER']="Adresse på FTP-Serveren";
$lang['L_HELP_FTPPORT']="Port på FTP-Serveren, standard: 21";
$lang['L_HELP_FTPUSER']="indtast brugernavn for FTP";
$lang['L_HELP_FTPPASS']="indtast kodeord for FTP";
$lang['L_HELP_FTPDIR']="hvor er upload-folderen? indtast sti!";
$lang['L_HELP_SPEED']="Minimum og maksimum hastighed, standard er 50 til 5000 (for høje eller lave hastigheder kan forårsage timeouts!)";
$lang['L_SPEED']="Hastighedskontrol";
$lang['L_HELP_CRONEXECPATH']="Placering af Perl scripts.
Startpunkt er HTTP-Adressen (som Adresser i Browseren)
Tilladt er absolutte eller relative angivelser.";
$lang['L_CRON_EXECPATH']="Sti til Perl scripts";
$lang['L_HELP_CRONCOMPLETELOG']="Når aktiveret, skrives det fuldstændige output til complete_log-filen.
Dette er uafhængigt af tekstudskrifter";
$lang['L_HELP_FTP_MODE']="Hvis du oplever problemer med FTP-overførsel, brug passiv tilstand.";


?>