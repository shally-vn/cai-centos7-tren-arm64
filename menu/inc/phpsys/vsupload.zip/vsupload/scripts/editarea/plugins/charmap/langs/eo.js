editArea.add_lang("eo",{
charmap_but: "Ekranklavaro",
charmap_title: "Ekranklavaro",
charmap_choose_block: "Elekto de lingvo",
charmap_insert:"enmeti tiun signaron"
});
