<?php
$lang['L_DUMP_HEADLINE']="bi am backup mache..";
$lang['L_GZIP_COMPRESSION']="GZip-Kompression";
$lang['L_SAVING_TABLE']="Spichere Tabälle";
$lang['L_OF']="vo";
$lang['L_ACTUAL_TABLE']="Aktuelli Tabälle";
$lang['L_PROGRESS_TABLE']="Fortschritt Tabälle";
$lang['L_PROGRESS_OVER_ALL']="Fortschritt gsamt";
$lang['L_ENTRY']="Itrag";
$lang['L_DONE']="Alls gmacht!";
$lang['L_DUMP_SUCCESSFUL']="isch erfolgriich erstellt worde.";
$lang['L_UPTO']="bis";
$lang['L_EMAIL_WAS_SEND']="D E-Mail isch erfolriich verschickt worde an";
$lang['L_BACK_TO_CONTROL']="wiiter";
$lang['L_BACK_TO_OVERVIEW']="zrugg zur Übersicht";
$lang['L_DUMP_FILENAME']="Backup-Datei:";
$lang['L_WITHPRAEFIX']="mit Präfix";
$lang['L_DUMP_NOTABLES']="Es händ kei Tabällen i de Datenbank `<b>%s</b>` chöne gfunde werde.";
$lang['L_DUMP_ENDERGEBNIS']="Es sind <b>%s</b> Tabälle mit zäme <b>%s</b> Datesätz gsicheret worde.<br>";
$lang['L_MAILERROR']="Leider isch bim Verschicke vo de E-Mail en Fähler underloffe!";
$lang['L_EMAILBODY_ATTACH']="Im Aahang finded Si d Sicherig vo Ihrer MySQL-Datenbank.<br>Sicherig vo de Datenbank `%s` <br><br>Folgende Datei wurde erzeugt:<br><br>%s <br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['L_EMAILBODY_MP_NOATTACH']="Es isch e Multipart-Sicherig erstellt worde.<br>Die Sicherige werdet nöd als Aahang mitglieferet!<br>Sicherig vo de Datenbank `%s` <br><br>Folgendi Dateie sind erzügt worde:<br><br>%s<br><br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['L_EMAILBODY_MP_ATTACH']="Es isch e Multipart-Sicherig erstellt worde.<br>D Sicherige werdet i separate E-Mails als Anhang glieferet!<br>Sicherig vo de Datenbank `%s` <br><br>Folgendi Dateie sind erzügt worde:<br><br>%s<br><br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['L_EMAILBODY_FOOTER']="<br><br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['L_EMAILBODY_TOOBIG']="D Sicherig überschriitet d Maximalgrössi von %s und isch drum nöd aagehänkt worde.<br>Sicherig vo de Datenbank `%s` <br><br>Folgendi Datei isch erzügt worde:<br><br>%s <br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['L_EMAILBODY_NOATTACH']="S Backup isch nöd aaghänkt worde.<br>Sicherig vo de Datenbank `%s` <br><br>Folgendi Datei isch erzügt worde:<br><br>%s <br><br>Fründlichi Grüess<br><br>MySQLDumper<br>";
$lang['L_EMAIL_ONLY_ATTACHMENT']="... nume dr Aahang";
$lang['L_TABLESELECTION']="Tabälleuswahl";
$lang['L_SELECTALL']="ali uuswähle";
$lang['L_DESELECTALL']="Uswahl ufhebä";
$lang['L_STARTDUMP']="Backup starte";
$lang['L_LASTBUFROM']="sletschti Update vom";
$lang['L_NOT_SUPPORTED']="Das Backup cha diä Funktion nöd.";
$lang['L_MULTIDUMP']="Multidump: Es sind <b>%d</b> Datenbanke gesicheret worde.";
$lang['L_FILESENDFTP']="verschicke grad File via FTP... heb bitte e chli Geduld.";
$lang['L_FTPCONNERROR']="FTP-Verbindig nöd hergstellt! Verbindig mit";
$lang['L_FTPCONNERROR1']="als User";
$lang['L_FTPCONNERROR2']="nöd mögli";
$lang['L_FTPCONNERROR3']="FTP-Upload isch fählerhaft gsi!";
$lang['L_FTPCONNECTED1']="Verbunde mit";
$lang['L_FTPCONNECTED2']="uf";
$lang['L_FTPCONNECTED3']="gschribe";
$lang['L_NR_TABLES_SELECTED']="- mit %s gewählte Tabälle";
$lang['L_NR_TABLES_OPTIMIZED']="<span class=\"small\">%s Tabälle sind optimiert worde.</span>";
$lang['L_DUMP_ERRORS']="<p class=\"error\">%s Fähler ufträte: <a href=\"log.php?r=3\">aaluege</a></p>";
$lang['L_FATAL_ERROR_DUMP']="Fatale Fähler: d CREATE-Aawiisig vo de Tabelle '%s' i de Datenbank '%s' hät nöd chöne gläse werde!";


?>