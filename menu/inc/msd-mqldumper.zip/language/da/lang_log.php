<?php
$lang['L_LOG_DELETE']="slet Log";
$lang['L_LOGFILEFORMAT']="Logfilformat";
$lang['L_LOGFILENOTWRITABLE']="Kan <b>ikke</b> skrive Logfil!";
$lang['L_NOREVERSE']="Ældste indlæg først";
$lang['L_REVERSE']="Seneste indlæg først


";


?>