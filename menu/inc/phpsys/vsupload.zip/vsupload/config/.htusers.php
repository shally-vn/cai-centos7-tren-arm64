<?php
        // ensure this file is being included by a parent file
        if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
        $GLOBALS["users"]=array(
        array('admin','947271731d1369973b15683174548a26','/home','http://localhost','1','','7',1),
);
?>
